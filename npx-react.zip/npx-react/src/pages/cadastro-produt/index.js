import './index.scss';
import { Link } from "react-router-dom";
import React, { useEffect } from 'react';

export default function Produtos(){

    return(
        <div id="body-IndexCad">
            <title>Cadastro Produtos</title>
            <h1 id="selecione-text">Selecione qual marca de produto você quer cadastrar</h1>
        </div>
    )}