import './index.scss';
import React from 'react';

export default function Produtos(){

    return(
        <div id="body-IndexCad">
            <title>Cadastro Produtos</title>
            <h1 id="selecione-text">Selecione qual marca do produto que você quer cadastrar clicando nas marcas a cima</h1>
        </div>
    )}